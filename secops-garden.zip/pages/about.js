import Head from "next/head";

export default function About() {
  return (
    <div className="min-h-screen bg-blue-900 text-white flex flex-col items-center justify-center">
      <Head>
        <title>About SecOps Garden</title>
      </Head>
      <h1 className="text-4xl font-bold">About SecOps Garden</h1>
      <p className="text-lg mt-4">A fusion of cybersecurity experience and growth.</p>
    </div>
  );
}
