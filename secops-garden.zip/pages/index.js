import Head from "next/head";

export default function Home() {
  return (
    <div className="min-h-screen bg-green-900 text-white flex flex-col items-center justify-center">
      <Head>
        <title>SecOps Garden</title>
      </Head>
      <h1 className="text-5xl font-bold">Welcome to SecOps Garden</h1>
      <p className="text-xl mt-4">Blending Cybersecurity and Nature</p>
    </div>
  );
}
